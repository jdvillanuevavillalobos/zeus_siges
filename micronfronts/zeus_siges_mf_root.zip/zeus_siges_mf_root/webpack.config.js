const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const CssMinimizerPlugin = require('css-minimizer-webpack-plugin');
const TerserPlugin = require('terser-webpack-plugin');
const { GenerateSW } = require('workbox-webpack-plugin');

module.exports = (env, argv) => {
  const isProduction = argv.mode === 'production';

  return {
    entry: './src/index.js',
    output: {
      filename: '[name].[contenthash].js', // Nombres únicos para cada chunk
      path: path.resolve(__dirname, 'dist'),
      publicPath: '/',
      clean: true, // Limpia la carpeta dist antes de cada build
    },
    module: {
      rules: [
        {
          test: /\.jsx?$/, // Archivos .js o .jsx
          exclude: /node_modules/,
          use: {
            loader: 'babel-loader',
          },
        },
        {
          test: /\.css$/, // Archivos CSS
          use: [
            isProduction ? MiniCssExtractPlugin.loader : 'style-loader',
            'css-loader',
          ],
        },
        {
          test: /\.(png|jpg|jpeg|gif|svg|woff|woff2|eot|ttf|otf)$/i, // Archivos estáticos
          type: 'asset/resource',
        },
      ],
    },
    plugins: [
      new HtmlWebpackPlugin({
        template: './public/index.html',
      }),
      ...(isProduction
        ? [new MiniCssExtractPlugin({ filename: '[name].[contenthash].css' })]
        : []),
      new GenerateSW({
        clientsClaim: true,
        skipWaiting: true,
        runtimeCaching: [
          {
            urlPattern: /\.(?:js|css|html|png|jpg|jpeg|svg)$/,
            handler: 'CacheFirst',
            options: {
              cacheName: 'static-resources',
              expiration: {
                maxAgeSeconds: 30 * 24 * 60 * 60, // Cache por 30 días
              },
            },
          },
        ],
      }),
    ],
    optimization: {
      runtimeChunk: 'single', // Separa el runtime en un archivo independiente
      splitChunks: {
        chunks: 'all', // Divide los chunks de forma automática
      },
      minimize: isProduction,
      minimizer: [new CssMinimizerPlugin(), new TerserPlugin()],
    },
    devServer: {
      static: path.join(__dirname, 'public'),
      port: 9000,
      open: true,
      historyApiFallback: true, // Soporte para rutas dinámicas
    },
    resolve: {
      extensions: ['.js', '.jsx'],
    },
  };
};
