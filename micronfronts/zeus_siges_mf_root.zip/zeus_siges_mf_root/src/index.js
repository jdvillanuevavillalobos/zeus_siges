import './single-spa-config'; // Importa la configuración de aplicaciones
