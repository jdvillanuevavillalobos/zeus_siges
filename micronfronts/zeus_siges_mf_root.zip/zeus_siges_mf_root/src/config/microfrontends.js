export const microfrontends = [
    {
      name: 'zeus_siges_mf_header',
      url: 'http://localhost:8081/header.js',
      activeWhen: () => true,
      domElement: 'header',
    },
    {
      name: 'zeus_siges_mf_menu',
      url: 'http://localhost:8082/menu.js',
      activeWhen: () => true,
      domElement: 'menu',
    },
    {
      name: 'app1',
      url: 'http://localhost:8083/app1.js',
      activeWhen: (location) => location.pathname.startsWith('/app1'),
      domElement: 'content',
    },
    {
      name: 'app2',
      url: 'http://localhost:8084/app2.js',
      activeWhen: (location) => location.pathname.startsWith('/app2'),
      domElement: 'content',
    },
  ];
  