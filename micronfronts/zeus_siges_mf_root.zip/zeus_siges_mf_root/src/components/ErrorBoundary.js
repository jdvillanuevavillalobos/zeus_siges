import React from 'react';

/**
 * Componente ErrorBoundary.
 *
 * Captura errores de renderizado en sus componentes hijos y los maneja mostrando un mensaje
 * alternativo. También puede registrar los errores en herramientas de monitoreo.
 */
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, errorMessage: '' };
  }

  /**
   * Método del ciclo de vida que se ejecuta si ocurre un error en los hijos.
   * Actualiza el estado para mostrar un mensaje de error.
   *
   * @param {Error} error - El error capturado.
   */
  static getDerivedStateFromError(error) {
    return { hasError: true, errorMessage: error.message };
  }

  /**
   * Registra errores capturados y detalles adicionales.
   * @param {Error} error - El error capturado.
   * @param {object} errorInfo - Información adicional del error.
   */
  componentDidCatch(error, errorInfo) {
    console.error('Error capturado por ErrorBoundary:', error, errorInfo);
    // Puedes integrar herramientas como Sentry aquí.
    // Ejemplo: Sentry.captureException(error, { extra: errorInfo });
  }

  /**
   * Renderiza el contenido del ErrorBoundary.
   * Si hay un error, muestra un mensaje; de lo contrario, renderiza los hijos.
   */
  render() {
    if (this.state.hasError) {
      return (
        <div style={{ textAlign: 'center', color: 'red', fontWeight: 'bold' }}>
          <h1>⚠️ Algo salió mal</h1>
          <p>{this.state.errorMessage}</p>
        </div>
      );
    }
    return this.props.children;
  }
}

export default ErrorBoundary;
