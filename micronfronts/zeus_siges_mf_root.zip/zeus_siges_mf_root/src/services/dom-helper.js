/**
 * Obtiene un elemento del DOM por su ID.
 *
 * @param {string} domElementId - ID del elemento DOM a buscar.
 * @returns {HTMLElement|null} - El elemento DOM encontrado, o null si no existe.
 */
export function getDomElement(domElementId) {
    const element = document.getElementById(domElementId);
    if (!element) {
      console.warn(`No se encontró el elemento DOM con ID "${domElementId}".`);
      return null;
    }
    return element;
  }
  