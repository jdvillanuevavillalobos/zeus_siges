import { handleError } from './error-handler';

/**
 * Carga un microfrontend de manera segura.
 *
 * @param {string} appName - Nombre del microfrontend.
 * @param {string} url - URL del microfrontend.
 * @param {HTMLElement} domElement - Contenedor donde se renderiza.
 * @returns {Promise<object>} - Módulo del microfrontend.
 */
export async function safeImport(appName, url, domElement) {
  try {
    const response = await fetch(url, { method: 'HEAD' });
    if (!response.ok) {
      throw new Error(`El archivo ${url} no está disponible.`);
    }

    const appModule = await System.import(appName);

    const requiredExports = ['bootstrap', 'mount', 'unmount'];
    const missingExports = requiredExports.filter((exp) => !(exp in appModule));
    if (missingExports.length > 0) {
      throw new Error(
        `El módulo "${appName}" no exporta las funciones requeridas: ${missingExports.join(', ')}.`
      );
    }

    return appModule;
  } catch (error) {
    handleError(appName, domElement, error);
    return {
      bootstrap: () => Promise.resolve(),
      mount: () => Promise.resolve(),
      unmount: () => Promise.resolve(),
    };
  }
}

// Precarga microfrontends críticos
System.import('zeus_siges_mf_header');
System.import('zeus_siges_mf_menu');
