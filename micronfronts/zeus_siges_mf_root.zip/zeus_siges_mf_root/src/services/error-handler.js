export function handleError(appName, domElement, error) {
    console.error(`Error en ${appName}:`, error);
    if (domElement) {
      domElement.innerHTML = `
        <div style="color: red; font-weight: bold;">
          ⚠️ Error al cargar "${appName}".
        </div>`;
    }
  }
  