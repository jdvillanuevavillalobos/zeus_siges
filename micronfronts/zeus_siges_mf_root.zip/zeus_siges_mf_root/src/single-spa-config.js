// Importa las funciones principales de Single-SPA para registrar y activar aplicaciones
import { registerApplication, start } from 'single-spa';
import { microfrontends } from './config/microfrontends';
import { safeImport } from './services/microfrontend-loader';
import { getDomElement } from './services/dom-helper';

/**
 * Precarga los microfrontends críticos antes de que sean necesarios.
 * Esto mejora la percepción de velocidad para los usuarios.
 */
function preloadMicrofrontends() {
  ['zeus_siges_mf_header', 'zeus_siges_mf_menu'].forEach((name) => {
    System.import(name).catch((error) => {
      console.warn(`Error precargando el microfrontend "${name}":`, error);
    });
  });
}

/**
 * Registro dinámico de microfrontends
 *
 * Este bloque recorre la configuración centralizada de `microfrontends` y realiza lo siguiente:
 * - Verifica si los datos de configuración son válidos.
 * - Obtiene el contenedor DOM donde debe renderizarse cada microfrontend.
 * - Registra cada microfrontend en Single-SPA.
 */
microfrontends.forEach(({ name, url, activeWhen, domElement }) => {
  // Validación básica de la configuración
  if (!name || !url || !activeWhen || !domElement) {
    console.warn(`Configuración incompleta para el microfrontend:`, { name, url, activeWhen, domElement });
    return;
  }

  // Obtén el elemento DOM donde se renderizará el microfrontend
  const element = getDomElement(domElement);

  // Si el contenedor no existe, omite el registro y muestra una advertencia
  if (!element) {
    console.warn(`El contenedor DOM con ID "${domElement}" no existe. Saltando la aplicación "${name}".`);
    return;
  }

  // Registra la aplicación en Single-SPA
  registerApplication({
    name, // Nombre del microfrontend
    app: () => safeImport(name, url, element), // Carga segura del microfrontend
    activeWhen, // Define cuándo esta aplicación estará activa (rutas, siempre activa, etc.)
    customProps: { domElement: element }, // Propiedades personalizadas para el microfrontend
  });
});

// Precarga microfrontends críticos
preloadMicrofrontends();

// Inicia el sistema de Single-SPA
start();
